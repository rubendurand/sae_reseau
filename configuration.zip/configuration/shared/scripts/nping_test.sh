echo "nameserver 8.8.8.8" > /etc/resolv.conf

iptables -A INPUT -p udp --sport 53 -s 8.8.8.8 -j ACCEPT
iptables -A OUTPUT -p udp --dport 53 -d 8.8.8.8 -j ACCEPT

apt update
apt install -y nmap

./shared/scripts/tests.txt $1


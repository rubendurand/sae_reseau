#!/bin/bash


# Vérifier si le fichier existe
if [ ! -f "/shared/tests/tests_$1.txt" ]; then
    echo "Erreur : Le fichier $1 n'existe pas."
    exit 1
fi

if [ -f "results.txt" ]; then
    rm results.txt
fi

# Boucle sur chaque ligne du fichier
echo "Vérification de la connectivité réseau :"
while IFS=' ' read -r name target ports; do
    if [ -n "$name" ] && [ -n "$target" ] ; then
        # Vérification du ping
        ping -c 1 -w 1 "$target" &> /dev/null
        if [ $? -eq 0 ]; then
            echo "$name est accessible par ping."
            echo "$name : true" >> results.txt
        else
            echo "$name est injoignable par ping."
            echo "$name : false" >> results.txt
        fi
        
        # Vérification des ports s'ils sont spécifiés
        if [ -n "$ports" ]; then
            IFS=',' read -ra port_array <<< "$ports"
            for port_proto in "${port_array[@]}"; do
                IFS='/' read -r port proto <<< "$port_proto"
                nping --"$proto" -p "$port" -c 1 "$target" > temp_output.txt 2>/dev/null
                output=$(cat temp_output.txt)
                if echo "$output" | grep -q "RCVD"; then
                    echo "   Port $port ouvert sur $name."
                    echo "$name, $port, $proto : true" >> results.txt
                else
                    echo "   Port $port fermé ou injoignable sur $name."
                    echo "$name, $port, $proto : false" >> results.txt
                fi
            done
        fi
    fi
done < "/shared/tests/tests_$1.txt"


while IFS= read -r line1 && IFS= read -r line2 <&3; do
    if [ "$line1" != "$line2" ]; then
        echo "Erreur sur un test :"
        echo "Attentu : $line1"
        echo "Resultat : $line2"
    fi
done < "/shared/results/res_$1.txt" 3< "results.txt"

rm temp_output.txt
